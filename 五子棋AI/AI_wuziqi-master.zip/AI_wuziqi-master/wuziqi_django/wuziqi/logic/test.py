
# for i in range(10,5,-1):
#     # for j in range(11,15):
#     #     print("------")
#     #     print(j)
#     #     if j == 13:
#     #         break
#     print(i)

# def aa():
#     print("aa")
#     return True
#
# if False and aa():
#     print("ddd")
# print("reslut")

for i in range(1,1):
    # for j in range(9,8 - (4-1) + 4):
        print("i")