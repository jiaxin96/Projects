from checkboard.checkboard import CheckBoard


def open_file(filename):
    f = file('./log/' + str(filename), 'w+')
    return f


def record(file, x, y, type, index):
    file.write(str(x) + " " + str(y) + " " + str(type) + " " + str(index) + "\n")
    return file


def load(filename):
    checkboard = CheckBoard()
    f = file('./log/' + str(filename), 'r')
    while True:
        line = f.readline()
        if line:
            str_list = line.split()
            checkboard.put(int(str_list[0]), int(str_list[1]), int(str_list[2]))
        else:
            break
    f.close()
    return checkboard

def close_file(file):
    file.close()
