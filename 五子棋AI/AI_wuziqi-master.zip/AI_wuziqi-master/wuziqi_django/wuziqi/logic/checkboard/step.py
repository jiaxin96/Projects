TYPE_0 = 0
TYPE_1 = 1
TYPE_2 = 2

def get_relative_type(type):
    if type is TYPE_1:
        return TYPE_2
    elif type is TYPE_2:
        return TYPE_1
    else:
        return TYPE_0


class EmptyStep:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __eq__(self, other):
        return other.x == self.x and other.y == self.y

    def __str__(self):
        return "x:" + str(self.x) + " y:" + str(self.y) + "\n"

class WeightStep(EmptyStep):
    def __init__(self, x, y, weight):
        EmptyStep.__init__(self, x, y)
        self.weight = weight

    def __str__(self):
        return "x:" + str(self.x) + " y:" + str(self.y) + " weight:" + str(self.weight) + "\n"

    def __eq__(self, other):
        return EmptyStep.__eq__(self, other) and other.weight == self.weight

class Step(EmptyStep):
    def __init__(self, x, y, type):
        EmptyStep.__init__(self, x, y)
        self.type = type
        self.index = 0

    def set(self, x, y, type):
        self.x = x
        self.y = y
        self.type = type

    def get_other_type(self):
        if self.type == TYPE_1:
            return TYPE_2
        else:
            return TYPE_1

    def __eq__(self, other):
        return EmptyStep.__eq__(self, other) and other.type == self.type

    def __str__(self):
        return "x:" + str(self.x) + " y:" + str(self.y) + " type:" + str(self.type) + "\n"
