# coding=utf-8
from ..utils.list_utils import get_zero_list
import numpy as np
import random
from step import Step, EmptyStep
from step import TYPE_0, TYPE_1, TYPE_2


class CheckBoard:
    def __init__(self, size_x=10, size_y=10, win_size=5):
        self.size_x = size_x
        self.size_y = size_y
        self.win_size = win_size
        self.last_step = Step(TYPE_0, TYPE_0, TYPE_0)

        self.useable_point_list = []
        self.used_point_list = []

        # init checkboard list
        self.checkboard_list = []
        for i in range(self.size_y):
            self.checkboard_list.append(get_zero_list(self.size_x))
            for j in range(self.size_x):
                self.useable_point_list.append(EmptyStep(j, i))

    def get_command_checkboard(self):
        return self.checkboard_list

    def get_command_mat_checkboard(self):
        return np.mat(self.get_command_checkboard())

    def put(self, x, y, type):
        if x > self.size_x or y > self.size_y:
            raise BaseException("the point you have chosen is not at checkboard,this checkboard size is (" + \
                                str(self.size_x) + "," + str(self.size_y) + ")")
        if type is not TYPE_1:
            type = TYPE_2

        # 防止同一类型棋子连续走棋
        # 如果是第一步的话 self.last_step.type 值为0
        if self.last_step.type is TYPE_0 or self.last_step.type is not type:
            if self.checkboard_list[y][x] is not TYPE_0: # 代表这一点已经有过棋子
                return False

            self.last_step.set(x, y, type)
            self.checkboard_list[y][x] = type
            # 移除可用空白点
            self.useable_point_list.remove(EmptyStep(x, y))
            self.used_point_list.append(Step(x, y, type))
            return True
        else:
            raise "one person could not play double times at a moment"

    def super_put(self, x, y, type):
        if x > self.size_x or y > self.size_y:
            raise BaseException("the point you have chosen is not at checkboard,this checkboard size is (" + \
                                str(self.size_x) + "," + str(self.size_y) + ")")
        if type is not TYPE_1:
            type = TYPE_2
        if self.checkboard_list[y][x] is not TYPE_0: # 代表这一点已经有过棋子
                return False
        self.last_step.set(x, y, type)
        self.checkboard_list[y][x] = type
        # 移除可用空白点
        self.useable_point_list.remove(EmptyStep(x, y))
        self.used_point_list.append(Step(x, y, type))
        return True

    def get(self, x, y):
        if x < self.size_x and y < self.size_y and x >= 0 and y >= 0:
            return self.checkboard_list[y][x]
        else:
            return None
            # raise BaseException("the point you have chosen is not at checkboard,this checkboard size is (" + \
            #       str(self.size_x) + "," + str(self.size_y) + ")")

    # 通过判断每次最后走的一步棋子所在的八个方向是否存在5子相连来判断胜利✌️
    def is_finish(self):
        x = self.last_step.x
        y = self.last_step.y
        t = self.last_step.type

        # self.last_step.type 为 TYPE_0 时  是第一步
        if self.last_step.type is TYPE_0:
            return False

        if self.judge_x_iswin(t, x, y):  # x 方向
            print("x line have " + str(self.win_size) + " & type is " + str(t))
            return True
        elif self.judge_y_iswin(t, x, y):  # y 方向
            print("y line have " + str(self.win_size) + " & type is " + str(t))
            return True
        elif self.judge_xy_iswin(t, x, y):  # xy 左上方到右下方 方向
            print("xy line have " + str(self.win_size) + " & type is " + str(t))
            return True
        elif self.judge_yx_iswin(t, x, y):  # yx 右上方到左下方 方向
            print("yx line have " + str(self.win_size) + " & type is " + str(t))
            return True
        else:
            return False
        pass

    # 判断x方向是否有胜利状态
    def judge_x_iswin(self, t, x, y):
        x_count = 0
        for i in range(self.win_size):
            x_offset = x + i
            if self.get(x_offset, y) == t:
                x_count += 1
            else:
                for j in range(self.win_size - i):
                    x_offset = x - j - 1
                    if x_offset < 0:
                        break
                    if self.get(x_offset, y) == t:
                        x_count += 1
                break
        return x_count >= self.win_size

    # 判断y方向是否有胜利状态
    def judge_y_iswin(self, t, x, y):
        y_count = 0
        for i in range(self.win_size):
            y_offset = y + i
            if self.get(x, y_offset) == t:
                y_count += 1
            else:
                for j in range(self.win_size - i):
                    y_offset = y - j - 1
                    if y_offset < 0:
                        break
                    if self.get(x, y_offset) == t:
                        y_count += 1
                break
        return y_count >= self.win_size

    # xy 左上方到右下方 方向 是否有赢得状态
    def judge_xy_iswin(self, t, x, y):
        xy_count = 0
        for i in range(self.win_size):
            x_offset = x + i
            y_offset = y + i
            if self.get(x_offset, y_offset) == t:
                xy_count += 1
            else:
                for j in range(self.win_size - i):
                    x_offset = x - j - 1
                    y_offset = y - j - 1
                    if x_offset < 0 or y_offset < 0:
                        break
                    if self.get(x_offset, y_offset) == t:
                        xy_count += 1
                break
        return xy_count > self.win_size

    # yx 右上方到左下方 方向 是否有赢的状态
    def judge_yx_iswin(self, t, x, y):
        yx_count = 0
        for i in range(self.win_size):
            x_offset = x - i
            y_offset = y + i
            if x_offset >= 0 and self.get(x_offset, y_offset) == t:
                yx_count += 1
            else:
                for j in range(self.win_size - i):
                    x_offset = x + j + 1
                    y_offset = y - j - 1
                    if x_offset < 0 or y_offset < 0:
                        break
                    if self.get(x_offset, y_offset) == t:
                        yx_count += 1
                break
        return yx_count > self.win_size

    # 随机取出一个可填子的坐标
    def get_random_usable_x_y(self):
        usable_empty_step = random.choice(self.useable_point_list)
        return usable_empty_step.x, usable_empty_step.y

    def get_type_step_list(self, type):
        list = []
        for step in self.used_point_list:
            if step.type is type:
                list.append(step)
        return list

    def get_type1_step_list(self):
        return self.get_type_step_list(TYPE_1)

    def get_type2_step_list(self):
        return self.get_type_step_list(TYPE_2)

    # 获取权重分布棋盘展示
    def get_weight_checkboard_by_wight(self,weight_point_list):
        checkboard_list = []
        weight_useable_point_list = []
        for i in range(self.size_y):
            checkboard_list.append(get_zero_list(self.size_x))
            for j in range(self.size_x):
                weight_useable_point_list.append(EmptyStep(j, i))

        for weight_point in weight_point_list:
            checkboard_list[weight_point.y][weight_point.x] = weight_point.weight
        return checkboard_list

    def get_weight_checkboard_by_wight_mat(self,weight_point_list):
        return np.mat(self.get_weight_checkboard_by_wight(weight_point_list))

    # 重新开始
    def restart(self):
        self.__init__()