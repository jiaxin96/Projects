# coding=utf-8
from record.record import *
from checkboard.step import TYPE_0, TYPE_1, get_relative_type
from ai.strategy_1 import get_wight_mat, calc_next_result_list, calc_random_next_maxweight_result

# 模拟走棋 并记录走棋记录 i是当前步数
def put_step(i, record_file):
    # TODO: 这里x,y可能取不到  无解平局的情况
    x, y = checkboard.get_random_usable_x_y()
    if checkboard.get(x, y) is TYPE_0:
        print("[" + str(i) + "]" + " put (" + str(x) + "," + str(y) + ")" + "put_type:" + str(
                checkboard.last_step.get_other_type()))
        checkboard.put(x, y, checkboard.last_step.get_other_type())
        result = checkboard.is_finish()
        print(result)
        # 记录下每步操作
        record(record_file, x, y, checkboard.last_step.type, i)
        return result
    else:
        return put_step(i)


# 每局最大执行step_count步
def put_steps(step_count, record_file):
    for j in range(step_count):
        if put_step(j, record_file):
            break


# -------- 执行n局 ----------
# for i in range(100):
#     checkboard = CheckBoard(10, 10)
#     record_file = open_file(i)
#     put_steps(100,record_file)
#     record_file.close()

# -------- load from old data ---------------
# test_file_name = "3"
# print(load(test_file_name).get_command_mat_checkboard())
# get_wight_mat(load(test_file_name), TYPE_1)
# result_list = calc_next_result_list(load(test_file_name), TYPE_1)
# for result in result_list:
#     print(result)

# --------- start command game ---------
print("------game start------")
human_type = TYPE_1
checkboard = CheckBoard()
print(checkboard.get_command_mat_checkboard())
while not checkboard.is_finish():
    x = input("x=")
    y = input("y=")
    if int(x) >= checkboard.size_x or int(y) >= checkboard.size_y:
        print("please put x range on 0 ~ " + str(checkboard.size_x) + " & y range on 0 ~ " + str(checkboard.size_y))
        continue
    print("------ human go:" + "(x: " + str(x) + " y: " + str(y) + ") ------")
    if not checkboard.put(int(x), int(y), human_type):
        print("this point is already has chess,please choose anoter point")
        continue
    # ai go
    ai_weight_step = calc_random_next_maxweight_result(checkboard, get_relative_type(human_type))
    print("------ ai go:" + str(ai_weight_step) + " ------")
    checkboard.put(ai_weight_step.x, ai_weight_step.y, get_relative_type(human_type))

    print("=============")
    print("ai wight :")
    print(checkboard.get_weight_checkboard_by_wight_mat(get_wight_mat(checkboard,get_relative_type(human_type))))

    print("=============")
    print("human wight :")
    print(checkboard.get_weight_checkboard_by_wight_mat(get_wight_mat(checkboard,human_type)))

    print("=============")
    print("current checkboard :")
    print(checkboard.get_command_mat_checkboard())

print("game over")
