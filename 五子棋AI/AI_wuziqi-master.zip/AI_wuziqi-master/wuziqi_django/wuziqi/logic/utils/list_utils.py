
def get_zero_list(size):
    list = []
    for i in range(0,size):
        list.append(0)
    return list
