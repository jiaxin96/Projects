# coding=utf-8
import random
from ..checkboard.step import TYPE_0, TYPE_1, TYPE_2, get_relative_type, WeightStep


# 构造每个可走点的获胜数据权重 每次优先选取获胜栈最短的路线走 以及阻止对方的获胜栈达到最小
# 权重值代表这一空白点上,横纵斜向4个方向,如果可以赢,所赢结果中,路线中包含已走棋子的数量的最大值
# 这个权重越大 代表走这里越可能会赢
def get_wight_mat(checkboard, target_type):
    # 空余位置的权重分布
    useable_point_win_weight_list = []

    # 遍历每一个空白点
    for useable_point in checkboard.useable_point_list:
        # 初始化每个点的可赢权重都是0
        x_weight = y_weight = xy_weight = yx_weight = 0

        # 每个方向上进行5次位移,分别计算出每次位移产生的权重 最终要从这些权重中选出最大值
        for offset in range(0, checkboard.win_size):
            # 初始化某一次偏移的权重
            x_offset_weight = y_offset_weight = xy_offset_weight = yx_offset_weight = 0

            # ------开始偏移------
            # x 方向
            x_stop = False
            for p_x in range(useable_point.x, useable_point.x - checkboard.win_size + offset, -1):
                # TODO:this code could be extract
                if checkboard.get(p_x, useable_point.y) is target_type:
                    # offset_weight 是为了优化权重计算的变量,于当前棋子靠近的空位,权重值比较大
                    offset_weight = checkboard.win_size - offset
                    x_offset_weight += 10 + offset_weight
                elif checkboard.get(p_x, useable_point.y) is not TYPE_0:
                    x_offset_weight = 0
                    x_stop = True
                    break
            if offset > 0 and not x_stop:
                for p_x in range(useable_point.x + 1, useable_point.x + 1 + offset):
                    # TODO:this code could be extract
                    if checkboard.get(p_x, useable_point.y) is target_type:
                        # offset_weight 是为了优化权重计算的变量,于当前棋子靠近的空位,权重值比较大
                        offset_weight = checkboard.win_size - offset
                        x_offset_weight += 10 + offset_weight
                    elif checkboard.get(p_x, useable_point.y) is not TYPE_0:
                        x_offset_weight = 0
                        break

            # y 方向
            y_stop = False
            for p_y in range(useable_point.y, useable_point.y - checkboard.win_size + offset, -1):
                # TODO:this code could be extract
                if checkboard.get(useable_point.x, p_y) is target_type:
                    # offset_weight 是为了优化权重计算的变量,于当前棋子靠近的空位,权重值比较大
                    offset_weight = checkboard.win_size - offset
                    y_offset_weight += 10 + offset_weight
                elif checkboard.get(useable_point.x, p_y) is not TYPE_0:
                    y_offset_weight = 0
                    y_stop = True
                    break
            if offset > 0 and not y_stop:
                for p_y in range(useable_point.y + 1, useable_point.y + 1 + offset):
                    # TODO:this code could be extract
                    if checkboard.get(useable_point.x, p_y) is target_type:
                        # offset_weight 是为了优化权重计算的变量,于当前棋子靠近的空位,权重值比较大
                        offset_weight = checkboard.win_size - offset
                        y_offset_weight += 10 + offset_weight
                    elif checkboard.get(useable_point.x, p_y) is not TYPE_0:
                        y_offset_weight = 0
                        break

            # xy 方向 (左上到右下方向)
            xy_stop = False
            for p_x in range(useable_point.x, useable_point.x - checkboard.win_size + offset, -1):
                # TODO:this code could be extract
                p_y = useable_point.y + (p_x - useable_point.x)
                if checkboard.get(p_x, p_y) is target_type:
                    # offset_weight 是为了优化权重计算的变量,于当前棋子靠近的空位,权重值比较大
                    offset_weight = checkboard.win_size - offset
                    xy_offset_weight += 10 + offset_weight
                elif checkboard.get(p_x, p_y) is not TYPE_0:
                    xy_offset_weight = 0
                    xy_stop = True
                    break
            if offset > 0 and not xy_stop:
                for p_x in range(useable_point.x + 1, useable_point.x + 1 + offset):
                    # TODO:this code could be extract
                    p_y = useable_point.y + (p_x - useable_point.x)
                    if checkboard.get(p_x, p_y) is target_type:
                        # offset_weight 是为了优化权重计算的变量,于当前棋子靠近的空位,权重值比较大
                        offset_weight = checkboard.win_size - offset
                        xy_offset_weight += 10 + offset_weight
                    elif checkboard.get(p_x, p_y) is not TYPE_0:
                        xy_offset_weight = 0
                        break

            # yx 方向 (右上到左下方向)
            yx_stop = False
            for p_x in range(useable_point.x, useable_point.x - checkboard.win_size + offset, -1):
                # TODO:this code could be extract
                p_y = useable_point.y - (p_x - useable_point.x)
                if checkboard.get(p_x, p_y) is target_type:
                    # offset_weight 是为了优化权重计算的变量,于当前棋子靠近的空位,权重值比较大
                    offset_weight = checkboard.win_size - offset
                    yx_offset_weight += 10 + offset_weight
                elif checkboard.get(p_x, p_y) is not TYPE_0:
                    yx_offset_weight = 0
                    yx_stop = True
                    break
            if offset > 0 and not yx_stop:
                for p_x in range(useable_point.x + 1, useable_point.x + 1 + offset):
                    # TODO:this code could be extract
                    p_y = useable_point.y - (p_x - useable_point.x)
                    if checkboard.get(p_x, p_y) is target_type:
                        # offset_weight 是为了优化权重计算的变量,于当前棋子靠近的空位,权重值比较大
                        offset_weight = checkboard.win_size - offset
                        yx_offset_weight += 10 + offset_weight
                    elif checkboard.get(p_x, p_y) is not TYPE_0:
                        yx_offset_weight = 0
                        break
            # ------偏移结束------

            # 经过({胜利棋子数}-1)次的位移 选出权重最大的一次结果,记录下来
            if x_weight < x_offset_weight:
                x_weight = x_offset_weight
            if y_weight < y_offset_weight:
                y_weight = y_offset_weight
            if xy_weight < xy_offset_weight:
                xy_weight = xy_offset_weight
            if yx_weight < yx_offset_weight:
                yx_weight = yx_offset_weight

        # 选出四个方向中权重最大的结果,记为当前结果
        weight = max(x_weight, y_weight, xy_weight, yx_weight)

        useable_point_win_weight_list.append(WeightStep(useable_point.x, useable_point.y, weight))
    return useable_point_win_weight_list

    # print("useable point win weight list size >>>")
    # print(len(useable_point_win_weight_list))
    # for weight_point in useable_point_win_weight_list:
    #     print("(" + str(weight_point.x) + "," + str(weight_point.y) + ")" + " weight:" + str(weight_point.weight))


def calc_next_result_list(checkboard, next_type):
    # 分别取出赢的权重列表和输的权重列表
    # 将输赢权重列表每个点的权重相加,取出值最高的点,这一点就是下一步要走的点
    win_weight_list = get_wight_mat(checkboard, next_type)
    lose_weight_list = get_wight_mat(checkboard, get_relative_type(next_type))

    result_weight_list = []
    result = WeightStep(win_weight_list[0].x, win_weight_list[0].y, win_weight_list[0].weight)
    max_weight = 0
    for i in range(len(win_weight_list)):
        pw = win_weight_list[i]
        pl = lose_weight_list[i]
        if pw.x == pl.x and pw.y == pl.y:
            # 这里可以调整权重的计算 加大攻击 或者 加大防守
            sum_weight = pw.weight + pl.weight * 3
            result_weight_list.append(WeightStep(pw.x, pw.y, sum_weight))

            if max_weight < sum_weight:
                max_weight = sum_weight

    # 找出结果集中权重最大的结果集
    result_max_weight_list = []
    for step in result_weight_list:
        if step.weight == max_weight:
            result_max_weight_list.append(WeightStep(step.x, step.y, step.weight))

    return result_max_weight_list


# 从最大权重结果点集合中随机取一个作为结果
def calc_random_next_maxweight_result(checkboard, next_type):
    return random.choice(calc_next_result_list(checkboard, next_type))
