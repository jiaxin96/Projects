from manager import manager
from ..utils.singletion import singleton

@singleton
class managerFactory(object):

    def __init__(self):
        self.managerList = []

    def getManger(self,userCode):
        print("managerListSize:" + str(len(self.managerList)))
        for m in self.managerList:
            if userCode == m.get_user_code():
                print("get an old manager")
                return m

        print("create a new manager")
        m = manager(userCode)
        self.managerList.append(m)
        return m