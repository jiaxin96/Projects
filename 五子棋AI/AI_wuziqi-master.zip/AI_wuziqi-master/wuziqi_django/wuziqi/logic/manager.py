# coding=utf-8
# from record.record import *
from .ai.strategy_1 import get_wight_mat, calc_next_result_list, calc_random_next_maxweight_result
from .checkboard.step import TYPE_0, TYPE_1, get_relative_type
from .checkboard.checkboard import CheckBoard

class manager(object):
    ERROR_CODE_OUT_OF_RANGE = 1
    ERROR_CODE_ALLREADY_HAS_CHESS = 2

    def __init__(self,userCode):
        self.human_type = TYPE_1
        self.cb = CheckBoard()
        self.userCode = userCode

    def __eq__(self, other):
        return self.userCode is other.userCode

    def get_user_code(self):
        return self.userCode

    def get_human_type(self):
        return self.human_type

    def put(self, x, y):
        if int(x) >= self.cb.size_x or int(y) >= self.cb.size_y:
            print("please put x range on 0 ~ " + str(self.cb.size_x) + " & y range on 0 ~ " + str(
                self.cb.size_y))
            return self.ERROR_CODE_OUT_OF_RANGE

        print("------ human go:" + "(x: " + str(x) + " y: " + str(y) + ") ------")
        if not self.cb.put(int(x), int(y), self.human_type):
            print("this point is already has chess,please choose anoter point")
            return self.ERROR_CODE_ALLREADY_HAS_CHESS

        return self.get_checkboard_str()

    def ai_go(self):
        ai_weight_step = calc_random_next_maxweight_result(self.cb, get_relative_type(self.human_type))
        print("------ ai go:" + str(ai_weight_step) + " ------")
        self.cb.put(ai_weight_step.x, ai_weight_step.y, get_relative_type(self.human_type))

        return self.get_checkboard_str(),ai_weight_step.x,ai_weight_step.y

    # 返回人类获胜权重点棋盘棋子布局
    def get_human_win_weight(self):
        return self.cb.get_weight_checkboard_by_wight(get_wight_mat(self.cb, self.human_type))

    # 返回ai获胜权重点棋盘棋子布局
    def get_ai_win_weight(self):
        return self.cb.get_weight_checkboard_by_wight(get_wight_mat(self.cb, get_relative_type(self.human_type)))

    # 返回棋盘棋子布局
    def get_checkboard_str(self):
        return str(self.cb.get_command_checkboard()).replace(" ","")

    # 重新开始
    def restart(self):
        self.cb.restart()