
checkerboard_x = 10;
checkerboard_y = 10;

def set_checkerboard_size(x,y):
    checkerboard_x = x;
    checkerboard_y = y;
    pass

