//获取数据字符串
function warpChessData(cb_str){
    cb_str = cb_str.substring(1,cb_str.length-2)
    line_array = cb_str.split("],")

    chess_data = new Array()

    for(var i=0;i<line_array.length;i++){
        chess_data[i] = new Array()
        line_str = line_array[i].substring(1)
        item_array = line_str.split(",")

        for(var j=0;j<item_array.length;j++){
            chess_data[i][j] = item_array[j]
        }
    }

    return chess_data
}

function callAjax(url,callback){
    if (window.XMLHttpRequest) {
        // code for Firefox, Opera, IE7, etc.
        xmlhttp=new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }

    if (xmlhttp!=null) {
        xmlhttp.onreadystatechange=function()
            {
                if (xmlhttp.readyState==4 && xmlhttp.status==200) {
                    callback.call(this,xmlhttp.responseText)
                }
            }
        xmlhttp.open("GET",url,true);
        xmlhttp.send();
        xmlhttp.catch = false
    } else {
        alert("Your browser does not support XMLHTTP.");
    }
}

var canvas = new fabric.Canvas('canvas');

function draw(chess_data){

    var chess_row = chess_data.length
    var chess_cos = chess_data[0].length

    var item_width = canvas.getWidth()/chess_row * 0.9
    var item_heigh = canvas.getHeight()/chess_cos * 0.9

    for (var i=0;i<chess_data.length;i++){
        for (var j=0;j<chess_data[i].length;j++){
            chess = new fabric.Circle({
                radius: item_width/2.5,
                fill: '#f55',
                top: item_heigh * i,
                left: item_width * j,
                hasBorders:false,
                hasControls:false,
                selectable:false,
                pos_x:j,
                pos_y:i,
            })

            if (chess_data[i][j]=="0"){
                chess.fill = '#ff9'
            } else if(chess_data[i][j]=="1"){
                chess.fill = 'blue'
            } else {
                chess.fill = "red"
            }

            canvas.add(chess);
        }
    }

    canvas.renderAll();

}

function restart(){
    url = "?restart=1"
    callAjax(url,function(data){
        cb_data = warpChessData(data)
        draw(cb_data)
    })
}

var cb_str = document.getElementById("checkboard").innerHTML.trim()
var chess_data = warpChessData(cb_str)
draw(chess_data)

canvas.on({
    'mouse:down': function (e) {
        if (e.target) {
            var url = "?x=" + e.target.pos_x + "&y=" + e.target.pos_y
            callAjax(url,function(data){
                cb_data = warpChessData(data)
                draw(cb_data)
            })
        }
    },
})
