from django.shortcuts import render
from django.http import HttpResponse
import random
import time
from logic.manager import manager
from logic.managerFactory import managerFactory

def index(request):

    userCode = request.COOKIES.get('userCode', '')
    print("userCode:" + userCode)
    response = HttpResponse()
    if userCode is '':
        userCode = unicode("t:" + str(time.time()) + ",r:" + str(random.uniform(-100, 100)))
        print("set userCode:" + userCode)
        response.set_cookie("userCode",userCode)

    mf = managerFactory()
    m = mf.getManger(userCode)

    if "x" in request.GET and "y" in request.GET:
        x = request.GET["x"]
        y = request.GET["y"]
        m.put(x,y)
        print "human go: x=" + x + ",y=" + y
        s,ai_x,ai_y =m.ai_go()
        print "ai go: x=:" + str(ai_x) + ",y=" + str(ai_y)
        response.content = m.get_checkboard_str()
        return response

    if "restart" in request.GET:
        restart = request.GET["restart"]
        if restart == "1":
            print("restart")
            m.restart()
        response.content = m.get_checkboard_str()
        return response

    context = {
        "checkboard": m.get_checkboard_str()
    }

    return render(request, 'wuziqi/index.html',context)
