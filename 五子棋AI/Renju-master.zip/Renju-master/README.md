# Renju

QT版本五子棋，支持电脑AI和局域网双人PK。

## ScreenShots

<img src="./doc/img/home.png" width="420">
<img src="./doc/img/board.png" width="420">
<img src="./doc/img/listen.png" width="280">
<img src="./doc/img/search.png" width="280">
<img src="./doc/img/setting.png" width="280">

## Download

目前只编译了[Mac版本](https://github.com/shiyanhui/Renju/releases)，其他的系统
可能需要你用 QT(version >= 5.0) 源码编译。

## License

AGPL-3.
